# forager-starter

cd forager
npm install
npm run dev

#PORTS > 3000 > WebIcon


FOLDERS
-----------------

1. app
    - find "views" / screens with individual folders
    - to manipulate view, have page.jsx which is edited
    - files are .jsx not .html
        - .jsx vs. .js --> synatx highlighting better with .jsx
    - in views, add components


2. components

3. public
    - assets you share with world like PDF/image